<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Lab_report extends Model
{
    //
}
