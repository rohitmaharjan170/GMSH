<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Patient_Expenses extends Model
{
    //
}
