<?php

namespace App\Http\Controllers;

use App\Lab_report;
use Illuminate\Http\Request;

class LabReportController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Lab_report  $lab_report
     * @return \Illuminate\Http\Response
     */
    public function show(Lab_report $lab_report)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Lab_report  $lab_report
     * @return \Illuminate\Http\Response
     */
    public function edit(Lab_report $lab_report)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Lab_report  $lab_report
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Lab_report $lab_report)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Lab_report  $lab_report
     * @return \Illuminate\Http\Response
     */
    public function destroy(Lab_report $lab_report)
    {
        //
    }
}
