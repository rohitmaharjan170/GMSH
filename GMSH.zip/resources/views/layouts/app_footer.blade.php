        <!-- footer content -->
        <footer>
          <div class="pull-right">
          --- Ganesh Man Singh Hospital ---  |   <a href="https://snowbirdstudios.com.np/" target="_blank">Click Here For Technical Issues !</a>
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>