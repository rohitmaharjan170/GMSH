<form class="stock-form" method="post">
<div class="field item form-group">
  <label class="col-form-label col-md-3 col-sm-3  label-align">Quantity</label>
  <div class="col-md-6 col-sm-6">
    <input class="form-control" name="new_quantity" id="new_quantity" required="required" min=0 type="number"/></div>
</div>
</form>
